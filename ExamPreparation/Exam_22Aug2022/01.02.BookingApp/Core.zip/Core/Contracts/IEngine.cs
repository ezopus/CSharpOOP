﻿namespace BookingApp.Core.Contracts
{
    public interface IEngine
    {
        void Run();
    }
}
